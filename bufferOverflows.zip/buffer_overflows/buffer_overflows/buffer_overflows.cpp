// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  variable, and its position in the declaration. It must always be directly before the variable used for input.

	const std::string account_number = "CharlieBrown42";

	char user_input[20];

	std::cout << "Enter a value: ";
	// Use an if statement to verify difference between maximum limit of 20 characters and more
	// If the user input is 20 or less then offer the account number
	if (std::cin.getline(user_input, 20)) {
		std::cout << "You have entered: " << user_input << std::endl;
	}

	// Else if the user input is longer than 20, flag an error
	else {
		std::cout << "Account number is too long. Must be 20 characters or less." << std::endl;
		abort();
	}
	
	std::cout << "Your account number is " << account_number << std::endl;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
